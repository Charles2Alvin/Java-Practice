package Library;

import java.sql.*;
import java.util.Calendar;

public class userModel extends Model{
    public boolean retrieveDB() {
        try {
            //创建连接实例
            this.stmt = this.conn.createStatement();

            //构造sql查询语句
            String sql = "select * from users";
            ResultSet rs = this.stmt.executeQuery(sql);

            String titleFormat = "%-10s %20s %20s \n";
            System.out.printf(titleFormat,"USERNAME","PASS","EMAIL");
            System.out.println("------------------------------------------------");

            while (rs.next()) {

                String username = rs.getString("username");
                String pass = rs.getString("pass");
                String email = rs.getString("email");

                String format = "%-10s %20s %20s\n";
                System.out.printf(format, username, pass, email);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }
    public boolean updateDB(int id, String borrower) {
        try {
            this.stmt = this.conn.createStatement();
            //获取当前时间
            java.util.Date t = Calendar.getInstance().getTime();
            java.sql.Date time = new java.sql.Date(t.getTime());

            //预编译的sql语句
            String sql = "UPDATE `Library`.`books` SET `borrowTime` = ?, " +
                    "`borrower` = ?, `state` = 'true' WHERE (`id` = ?);";
            PreparedStatement pstmt = conn.prepareStatement(sql);

            //为预编译的占位符赋值
            pstmt.setDate(1, time);
            pstmt.setString(2, borrower);
            pstmt.setInt(3,id);

            //执行sql语句
            pstmt.execute();

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }
    public boolean signUP(String username, String pass, String email) {
        try {
            this.stmt = conn.createStatement();
            String sql = "";
            PreparedStatement pstmt = conn.prepareStatement(sql);

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return true;
    }
}
