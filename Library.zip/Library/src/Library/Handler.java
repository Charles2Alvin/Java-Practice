package Library;

public class Handler {
    public Model model;

    public Handler(Model model) {
        this.model = model;
    }

    public void doCmd() {

    }

    public boolean isQuit() {
        return false;
    }
}
